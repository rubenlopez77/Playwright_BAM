/**
 * Rule: uxmap-valid
 * Valida los UX Maps del modelo BAM.
 *
 * ✔ Verifica que cada entrada tenga selector y type válidos.
 * ✔ Evita duplicados dentro del archivo y entre archivos.
 * ✔ Permite solo tipos definidos (button, textbox, modal, etc.).
 */

import type { Rule } from "eslint";

const VALID_TYPES = new Set([
  "button",
  "textbox",
  "modal",
  "user-info",
  "link",
  "checkbox",
  "dropdown",
]);

// cache global para detectar duplicados cross-file
const seenSelectors = new Map<string, string>();

const rule: Rule.RuleModule = {
  meta: {
    type: "problem",
    docs: {
      description:
        "Valida la estructura de los UX Maps (selector, type y duplicados)",
      recommended: false,
    },
    schema: [],
    messages: {
      emptySelector: "Selector vacío en UX map.",
      invalidType:
        'Tipo inválido "{{type}}". Válidos: {{allowed}}',
      dupInFile: 'Selector duplicado en el archivo: "{{selector}}".',
      dupCrossFile:
        'Selector duplicado entre archivos: "{{selector}}" ya usado en {{prev}}.',
    },
  },

  create(context) {
    const filename = context.getFilename().replace(/\\/g, "/");
    const isUxFile =
      filename.includes("/src/ux/") && filename.endsWith(".ux.ts");
    if (!isUxFile) return {};

    const selectorsInFile = new Set<string>();

    return {
      ObjectExpression(node) {
        // Busca pares { selector: '...', type: '...' }
        const props = new Map<string, string>();
        for (const p of node.properties) {
          if (p.type !== "Property" || p.key.type !== "Identifier") continue;
          const key = p.key.name;
          if (key === "selector" || key === "type") {
            if (
              p.value.type === "Literal" &&
              typeof p.value.value === "string"
            ) {
              props.set(key, p.value.value);
            }
          }
        }

        if (!props.size) return;
        const selector = (props.get("selector") ?? "").trim();
        const type = (props.get("type") ?? "").trim();

        // selector vacío
        if (!selector) {
          context.report({ node, messageId: "emptySelector" });
        }

        // tipo inválido
        if (type && !VALID_TYPES.has(type)) {
          context.report({
            node,
            messageId: "invalidType",
            data: { type, allowed: Array.from(VALID_TYPES).join(", ") },
          });
        }

        // duplicado en el mismo archivo
        if (selector && selectorsInFile.has(selector)) {
          context.report({
            node,
            messageId: "dupInFile",
            data: { selector },
          });
        } else if (selector) {
          selectorsInFile.add(selector);
        }

        // duplicado entre archivos
        if (selector) {
          const prev = seenSelectors.get(selector);
          if (prev && prev !== filename) {
            context.report({
              node,
              messageId: "dupCrossFile",
              data: { selector, prev },
            });
          } else {
            seenSelectors.set(selector, filename);
          }
        }
      },

      // Limpieza de cache al salir del archivo
      "Program:exit"() {
        for (const [sel, file] of Array.from(seenSelectors.entries())) {
          if (file === filename && !selectorsInFile.has(sel)) {
            seenSelectors.delete(sel);
          }
        }
      },
    };
  },
};

export default rule;
