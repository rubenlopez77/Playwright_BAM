import type { Rule } from "eslint";


const DEFAULT_TYPES = new Set([
  "button",
  "textbox",
  "modal",
  "user-info",
  "link",
  "checkbox",
  "dropdown",
]);

const seenSelectors = new Map<string, string>();

const rule: Rule.RuleModule = {
  meta: {
    type: "problem",
    docs: {
      description: "Validate BAM UX Maps (selector, type, duplicates)",
      recommended: false,
    },
    schema: [],
    messages: {
      emptySelector: "Selector vacío en UX map.",
      invalidType:
        'Tipo inválido "{{type}}". Tipos válidos: {{allowed}}',
      dupInFile: 'Selector duplicado en el archivo: "{{selector}}".',
      dupCrossFile:
        'Selector duplicado entre archivos: "{{selector}}" ya usado en {{prev}}',
    },
  },

  create(context) {
    const filename = context.getFilename().replace(/\\/g, "/");
    const isUxFile =
      filename.includes(`/src/ux/`) && filename.endsWith(".ux.ts");

    if (!isUxFile) return {};

    const selectorsInFile = new Set<string>();

    return {
      ObjectExpression(node) {
        const props = new Map<string, string>();
        for (const p of node.properties) {
          if (p.type !== "Property" || p.key.type !== "Identifier") continue;
          const key = p.key.name;
          if (key === "selector" || key === "type") {
            if (
              p.value.type === "Literal" &&
              typeof p.value.value === "string"
            ) {
              props.set(key, p.value.value);
            }
          }
        }

        if (!props.size) return;
        const selector = (props.get("selector") ?? "").trim();
        const type = (props.get("type") ?? "").trim();

        if (!selector) {
          context.report({ node, messageId: "emptySelector" });
        }

        if (type && !DEFAULT_TYPES.has(type)) {
          context.report({
            node,
            messageId: "invalidType",
            data: { type, allowed: Array.from(DEFAULT_TYPES).join(", ") },
          });
        }

        if (selector && selectorsInFile.has(selector)) {
          context.report({
            node,
            messageId: "dupInFile",
            data: { selector },
          });
        } else if (selector) {
          selectorsInFile.add(selector);
        }

        if (selector) {
          const prev = seenSelectors.get(selector);
          if (prev && prev !== filename) {
            context.report({
              node,
              messageId: "dupCrossFile",
              data: { selector, prev },
            });
          } else {
            seenSelectors.set(selector, filename);
          }
        }
      },

      "Program:exit"() {
        for (const [sel, file] of Array.from(seenSelectors.entries())) {
          if (file === filename && !selectorsInFile.has(sel)) {
            seenSelectors.delete(sel);
          }
        }
      },
    };
  },
};

export default rule;
