/**
 * ESLint Rule: test-enforce-pattern
 * Enforce el patrón declarativo de BAM en los tests:
 *
 *  Debe comenzar con:  const user = this.getPage(Clase);
 * Solo se permiten llamadas user.metodo() y expect(...)
 * No se permite async ni await
 *
 * Compatible con ESLint v9+ y TypeScript 5+
 */

import type { Rule } from "eslint";

const rule: Rule.RuleModule = {
  meta: {
    type: "problem",
    docs: {
      description:
        "Enforce BAM declarative test pattern: const user = this.getPage(Class); user.method(); expect()...",
      recommended: false,
    },
    schema: [],
    messages: {
      firstStmtPattern:
        "El primer statement del test debe ser: const <var> = this.getPage(Clase);",
      noAwait: "BAM: no se permite 'await' dentro de tests.",
      noAsyncTestFn: "BAM: el callback del test no debe ser async.",
      onlyUserCalls:
        "Solo se permiten llamadas user.metodo() o expect() después de obtener la página.",
    },
  },

  create(context) {
    /** Helper: verificar si el nodo es un identificador con nombre opcional */
    function isIdentifier(node: any, name?: string): node is { name: string } {
      return (
        node &&
        node.type === "Identifier" &&
        (name ? node.name === name : true)
      );
    }

    /** Helper: detectar this.getPage(...) */
    function isGetPageCall(node: any): boolean {
      return (
        node?.type === "CallExpression" &&
        node.callee?.type === "MemberExpression" &&
        node.callee.object?.type === "ThisExpression" &&
        node.callee.property?.type === "Identifier" &&
        node.callee.property.name === "getPage"
      );
    }

    /** Helper: detectar expect(...) */
    function isExpectCall(node: any): boolean {
      if (node?.type !== "CallExpression") return false;
      if (isIdentifier(node.callee, "expect")) return true;

      // expect(...).toBe(...) → callee.object.callee.name === "expect"
      if (
        node.callee?.type === "MemberExpression" &&
        node.callee.object?.type === "CallExpression" &&
        isIdentifier(node.callee.object.callee, "expect")
      ) {
        return true;
      }
      return false;
    }

    return {
      CallExpression(node) {
        // Detecta llamadas a test(), it() o scenario()
        if (
          node.callee.type !== "Identifier" ||
          !["test", "it", "scenario"].includes(node.callee.name)
        ) {
          return;
        }

        // Segundo argumento debe ser una función (callback)
        const callback = node.arguments?.[1];
        if (
          !callback ||
          (callback.type !== "ArrowFunctionExpression" &&
            callback.type !== "FunctionExpression")
        ) {
          return;
        }

        // Reporta async prohibido
        if (callback.async) {
          context.report({ node: callback, messageId: "noAsyncTestFn" });
        }

        // Obtiene el cuerpo del test solo si es un bloque
        const body =
          callback.body.type === "BlockStatement" ? callback.body.body : [];

        // Si no hay cuerpo, nada que analizar
        if (!Array.isArray(body) || body.length === 0) return;

        // Primer statement debe ser: const user = this.getPage(Clase);
        const first = body[0];
        if (
          !first ||
          first.type !== "VariableDeclaration" ||
          first.kind !== "const" ||
          first.declarations.length !== 1
        ) {
          context.report({ node: first ?? callback, messageId: "firstStmtPattern" });
          return;
        }

        const decl = first.declarations[0];
        const init = decl?.init;
        if (!isGetPageCall(init)) {
          context.report({ node: decl, messageId: "firstStmtPattern" });
          return;
        }

        const userVar =
          decl.id.type === "Identifier" ? decl.id.name : "user";

          // Resto de statements
        for (let i = 1; i < body.length; i++) {
          const stmt = body[i];

          // Solo analizamos statements ejecutables
          if (stmt.type !== "ExpressionStatement") continue;

          const expr = stmt.expression;

          // await user.method()
          if (expr.type === "AwaitExpression") {
            context.report({ node: stmt, messageId: "noAwait" });
            continue;
          }

          // user.metodo()
          if (
            expr.type === "CallExpression" &&
            expr.callee?.type === "MemberExpression" &&
            expr.callee.object?.type === "Identifier" &&
            expr.callee.object.name === userVar
          ) {
            continue;
          }

          // expect(...)
          if (expr.type === "CallExpression" && isExpectCall(expr)) {
            continue;
          }

          //  Cualquier otra llamada no permitida
          if (expr.type === "CallExpression") {
            context.report({ node: stmt, messageId: "onlyUserCalls" });
            
          }
        }

      },
    };
  },
};

export default rule;
